// $(document).ready(function() {
//     $(".step").hide();
//     $("#step-1").show();

//     $(".next-step").click(function() {
//         var currentStep = $(this).data("step");
//         $("#step-" + currentStep).show();
//         $(this).closest(".step").hide();
//     });

//     $(".prev-step").click(function() {
//         var currentStep = $(this).data("step");
//         $("#step-" + currentStep).show();
//         $(this).closest(".step").hide();
//     });

//     $("#multi-step-form").submit(function(e) {
//         e.preventDefault(); // Prevent the form from submitting
//         // You can perform additional validation and submission logic here
//     });
// });


